﻿//example provided by http://www.cookingwithunity.com/

using UnityEngine;
using System.Collections;

public class DieValue : MonoBehaviour
{
	public int value = 1;
}
