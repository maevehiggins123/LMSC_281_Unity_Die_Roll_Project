# LMSC_281_Unity_Die_Roll_Project
This project is the starting point for a LMSC-281 Logic and Programming assignment on probability.
